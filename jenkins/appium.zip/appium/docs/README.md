# docs

##doc site

Formatted doc is [here](http://appium.io/documentation.html?lang=en).

##doc translation

At the moment we are focusing on improving the english documentation. When it 
is done we are planning to setup proper i18n l10n processes so that it is 
easier for people to help in translating the documentation.
